package com.example.audioapp.model

data class Song(val name: String, val path: String)
